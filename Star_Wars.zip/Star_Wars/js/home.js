export default class Home{
    constructor(){
        this.ShowDatas();
    }

    async loadFilms(){
        const response = await fetch("https://bgs.jedlik.eu/swapi/api/films",
        
        {
            method:  "GET",
            headers:{
                "Content-Type": "appliccation/json",
            },
        }
        );
        return await response.json();
    }

    async ShowDatas(){
        const films = await this.loadFilms();
        console.log(films);

        const crawl = document.querySelector('#crawl');
        const producer = document.querySelector('#producer');
        const director = document.querySelector('#director');
        const divimg = document.querySelector('#imgdiv');

        films.forEach(film => {
            if (film.title == "Revenge of the Sith") {
                crawl.innerHTML = film.opening_crawl;
                producer.innerHTML += film.producer;
                director.innerHTML += film.director;
                const img = document.createElement('img');
                img.src = `https://bgs.jedlik.eu/swimages/films/${film.id}.jpg`;
                img.id = "mainImage";
                divimg.append(img);
                
            }
        });
    }
}