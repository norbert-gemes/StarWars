export default class Spaceships {
  constructor() {
    this.showStarshipsCards();
  }

  async loadSpaceships() {
    const response = await fetch(
      "https://bgs.jedlik.eu/swapi/api/group/starships?ids=2,32,48,59,61,63,64,65,66,68,74,75",
      {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      }
    );
    return await response.json();
  }

  async loadFilms() {
    const response = await fetch("https://bgs.jedlik.eu/swapi/api/films", {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    });
    return await response.json();
  }

  async showStarshipsCards() {
    const ships = await this.loadSpaceships();
    const films = await this.loadFilms();
    console.log(ships);
    const divRows = document.querySelectorAll(".row");

    // Add a single click event listener to the document.body
    document.body.addEventListener("click", function (event) {
      // Check if the clicked element is the close button inside the planet-info div
      if (event.target.classList.contains("close-button")) {
        closeStarshipInfo();
      }
    });

    ships.forEach((ship) => {
      // Create a new div element for the current planet
      const newDiv = document.createElement("div");
      newDiv.className = "col-12 col-md-3 col-sm-6";

      // Create a new image element for the current planet
      const newImage = document.createElement("img");
      newImage.id = ship.name;
      newImage.className = "divship";
      newImage.src = `https://bgs.jedlik.eu/swimages/starships/${ship.id}.jpg`;
      newImage.alt = ship.name;
      newImage.width = 200;
      newImage.height = 150;

      // Add a click event listener to the image
      newImage.addEventListener("click", function () {
        // Create a new div for displaying planet information
        const shipInfoDiv = document.createElement("div");
        shipInfoDiv.className = "ship-info";
        shipInfoDiv.style.position = "fixed";
        shipInfoDiv.style.top = "0";
        shipInfoDiv.style.right = "0";
        shipInfoDiv.style.height = "auto";
        shipInfoDiv.style.width = "450px";
        shipInfoDiv.style.padding = "10px";
        shipInfoDiv.style.backgroundImage = "url(adrian.jpg)";
        shipInfoDiv.style.boxShadow = "0 0 10px rgba(0, 0, 0, 0.5)";

        const shipFilms = films.filter((film) => ship.films.includes(film.id));
        // Populate the planet information div with data
        shipInfoDiv.innerHTML = `
        <h2 id="ship_h2">${ship.name}</h2>
        <div class="film-info-content">
          <div class="film-list">
            ${shipFilms
              .map(
                (film) => `
              <div class="film-item" height="10%">
                <p height="10%" class="datas_p_ship">${film.title} <img src="https://bgs.jedlik.eu/swimages/films/${film.id}.jpg" alt="${film.title}" width="40%" height="10%" class="data_image"/></p>
              </div>`
              )
              .join("")}
          </div>
          <button class="close-button" onclick="toggleFilmInfo()">Close</button>
        </div>
      `;

        // Append the planet information div to the document body
        document.body.appendChild(shipInfoDiv);
        function toggleFilmInfo() {
          planetInfoDiv.classList.toggle("open");
        }
      });

      // Append the image to the div
      newDiv.appendChild(newImage);

      // Determine the appropriate row to append the div based on the planet ID
      if (ship.id <= 59) {
        divRows[0].appendChild(newDiv);
      } else if (ship.id <= 65) {
        divRows[1].appendChild(newDiv);
      } else {
        divRows[2].appendChild(newDiv);
      }
    });
  }
}

function closeStarshipInfo() {
  const shipInfoDiv = document.querySelector(".ship-info");
  if (shipInfoDiv) {
    shipInfoDiv.remove();
  }
}
// ["2","32","48","59","61","63","64","65","66","68","74","75"]
