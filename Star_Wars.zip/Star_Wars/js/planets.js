export default class Planets {
  constructor() {
    this.showPlanetsCards();
  }

  async loadPlanets() {
    const response = await fetch(
      "https://bgs.jedlik.eu/swapi/api/group/planets?ids=1,2,5,8,9,12,13,14,15,16,17,18,19",
      {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      }
    );
    return await response.json();
  }

  async loadFilms() {
    const response = await fetch("https://bgs.jedlik.eu/swapi/api/films", {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    });
    return await response.json();
  }

  async showPlanetsCards() {
    const planets = await this.loadPlanets();
    const films = await this.loadFilms();
    console.log(planets);
    const divRows = document.querySelectorAll(".row");

    // Add a single click event listener to the document.body
    document.body.addEventListener("click", function (event) {
      // Check if the clicked element is the close button inside the planet-info div
      if (event.target.classList.contains("close-button")) {
        closePlanetInfo();
      }
    });

    planets.forEach((planet) => {
      // Create a new div element for the current planet
      const newDiv = document.createElement("div");
      newDiv.className = "col-12 col-md-3 col-sm-6";

      // Create a new image element for the current planet
      const newImage = document.createElement("img");
      newImage.id = planet.name;
      newImage.className = "divplanet";
      newImage.src = `https://bgs.jedlik.eu/swimages/planets/${planet.id}.jpg`;
      newImage.alt = planet.name;
      newImage.width = 200;
      newImage.height = 150;

      // Add a click event listener to the image
      newImage.addEventListener("click", function () {
        // Create a new div for displaying planet information
        const planetInfoDiv = document.createElement("div");
        planetInfoDiv.className = "planet-info";
        planetInfoDiv.style.position = "fixed";
        planetInfoDiv.style.top = "0";
        planetInfoDiv.style.right = "0";
        planetInfoDiv.style.height = "800px";
        planetInfoDiv.style.width = "450px";
        planetInfoDiv.style.padding = "10px";
        planetInfoDiv.style.backgroundColor = "#fff";
        planetInfoDiv.style.boxShadow = "0 0 10px rgba(0, 0, 0, 0.5)";

        const planetFilms = films.filter((film) =>
          planet.films.includes(film.id)
        );
        // Populate the planet information div with data
        planetInfoDiv.innerHTML = `
                <h2>${planet.name}</h2>
                <p>Films:${planetFilms.map((film) => film.title).join(",")}</p>
              
                <button class="close-button">Close</button>
            `;

        // Append the planet information div to the document body
        document.body.appendChild(planetInfoDiv);
      });

      // Append the image to the div
      newDiv.appendChild(newImage);

      // Determine the appropriate row to append the div based on the planet ID
      if (planet.id <= 8) {
        divRows[0].appendChild(newDiv);
      } else if (planet.id <= 14) {
        divRows[1].appendChild(newDiv);
      } else {
        divRows[2].appendChild(newDiv);
      }
    });
  }

  // Function to close the planet information div
}
function closePlanetInfo() {
  const planetInfoDiv = document.querySelector(".planet-info");
  if (planetInfoDiv) {
    planetInfoDiv.remove();
  }
}

//1,2,5,8,9,12,13,14,15,16,17,18,19
